package com.main.epayphmain;

public class UserSession {
    private static UserSession instance;

    private String verifyStatus;
    private String pasD;
    private String BY;
    private String EmL;
    private boolean bol;

    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    // Getters and Setters from controller class

    public String getVerifyStatus(){ return verifyStatus; }
    public void setVerifyStatus(String verifyStatus){ this.verifyStatus = verifyStatus; }

    public String getPasD() { return pasD; }
    public void setPasD(String pasD) { this.pasD = pasD; }

    public String getBY() { return BY; }
    public void setBY(String BY) { this.BY = BY; }

    public String getEmL() { return EmL; }
    public void setEmL(String EmL) { this.EmL = EmL; }

    public boolean isBol() { return bol; }
    public void setBol(boolean bol) { this.bol = bol; }


    //Getters and Setters from profile
    private String userEmail;
    private String fullname = "";
    private String age = "";
    private String birthday = "";
    private String gender = "";
    private String cardnumber = "";
    private String savingsnumber = "";
    private String password = "";
    private String pin = "";
    private String status = "";

    public String getUserEmail(){ return userEmail; }
    public void setUserEmail(String userEmail){ this.userEmail = userEmail; }

    public String getFullname(){ return fullname; }
    public void setFullname(String fullname){ this.fullname = fullname; }

    public String getAge(){ return age; }
    public void setAge(String age){ this.age = age; }

    public String getBirthday(){ return birthday; }
    public void setBirthday(String birthday){ this.birthday = birthday; }

    public String getGender(){ return gender; }
    public void setGender(String gender){ this.gender = gender; }

    public String getCardnumber(){ return cardnumber; }
    public void setCardnumber(String cardnumber){ this.cardnumber = cardnumber; }

    public String getSavingsnumber(){ return savingsnumber; }
    public void setSavingsnumber(String savingsnumber){ this.savingsnumber = savingsnumber; }

    public String getPassword(){ return password; }
    public void setPassword(String password){ this.password = password; }

    public String getPin(){ return pin; }
    public void setPin(String pin){ this.pin = pin; }

    public String getStatus(){ return status; }
    public void setStatus(String status){ this.status = status; }


    private String currentEmail;
    public String getCurrentEmail(){ return currentEmail; }
    public void setCurrentEmail (String currentEmail){ this.currentEmail = currentEmail; }

    private String userCardNumber;
    public void setUserCardNumber(String userCardNumber){ this.userCardNumber = userCardNumber; }
    public String getUserCardNumber(){ return userCardNumber; }

    private String currentFullname;
    public void setCurrentFullname(String currentFullname){ this.currentFullname = currentFullname; }
    public String getCurrentFullname(){ return currentFullname; }

    private String transactioID;
    public void setTransactioID(String transactioID){ this.transactioID = transactioID; }
    public String getTransactioID(){ return transactioID; }

    private String changePass;
    public void setChangePass(String changePass){ this.changePass = changePass; }
    public String getChangePass(){ return  changePass; }

    private double savingsbal;
    public void setSavingsbal(double savingsbal){ this.savingsbal = savingsbal; }
    public double getSavingsbal(){ return savingsbal; }


    private double cardnoBal;
    public void setCardnoBal(double cardnoBal){ this.cardnoBal = cardnoBal; }
    public double getCardnoBal(){ return cardnoBal; }


    private double newBal;
    public void setnewBal(double newBal){ this.newBal = newBal; }
    public double getnewBal(){ return newBal; }

    private double atmBal;
    public void setAtmBal(double atmBal){ this.newBal = atmBal; }
    public double getAtmBal(){ return newBal; }

}

