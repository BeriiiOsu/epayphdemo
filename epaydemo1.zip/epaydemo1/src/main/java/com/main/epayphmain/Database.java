package com.main.epayphmain;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
    public Connection link;
    public Connection getLink(){
        String name = "epayuserdatabase";
        String user = "root";
        String pass = "0tnuP5@#";
        String url = "jdbc:mysql://localhost:3306/" + name;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            link = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return link;
    }
}
